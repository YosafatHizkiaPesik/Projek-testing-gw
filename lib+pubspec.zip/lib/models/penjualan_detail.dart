class PenjualanDetail {
  final int id;
  final int penjualanHeaderId;
  final int gudangId;
  final int barangId;
  final int jumlah;
  final int harga;
  final int diskon;
  final int subtotal;

  PenjualanDetail({
    required this.id,
    required this.penjualanHeaderId,
    required this.gudangId,
    required this.barangId,
    required this.jumlah,
    required this.harga,
    required this.diskon,
    required this.subtotal,
  });

  factory PenjualanDetail.fromJson(Map<String, dynamic> json) {
    return PenjualanDetail(
      id: json['id'],
      penjualanHeaderId: json['penjualan_header_id'],
      gudangId: json['gudang_id'],
      barangId: json['barang_id'],
      jumlah: json['jumlah'],
      harga: json['harga'],
      diskon: json['diskon'],
      subtotal: json['subtotal'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'penjualan_header_id': penjualanHeaderId,
      'gudang_id': gudangId,
      'barang_id': barangId,
      'jumlah': jumlah,
      'harga': harga,
      'diskon': diskon,
      'subtotal': subtotal,
    };
  }
}
