import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import '../models/penjualan_detail.dart';
import '../utils/constants.dart';
import 'auth_controller.dart';

class PenjualanDetailController extends GetxController {
  var penjualanDetails = <PenjualanDetail>[].obs;
  var isLoading = false.obs;
  var errorMessage = ''.obs;

  final AuthController _authController = Get.find<AuthController>();

  Future<void> fetchPenjualanDetails(int penjualanHeaderId) async {
    try {
      isLoading.value = true;
      final token = _authController.token;
      final headers = {
        'Accept': 'application/json',
        'Authorization': 'Bearer $token',
      };
      final response = await http.get(
        Uri.parse('${ApiEndpoints.PENJUALAN_DETAIL}?penjualan_header_id=$penjualanHeaderId'),
        headers: headers,
      );
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        penjualanDetails.value = (data as List)
            .map((item) => PenjualanDetail.fromJson(item))
            .toList();
      } else {
        errorMessage.value = 'Failed to fetch penjualan details';
      }
    } catch (e) {
      errorMessage.value = e.toString();
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> addPenjualanDetail(PenjualanDetail detail) async {
    try {
      final token = _authController.token;
      final headers = {
        'Accept': 'application/json',
        'Authorization': 'Bearer $token',
      };
      final response = await http.post(
        Uri.parse(ApiEndpoints.PENJUALAN_DETAIL),
        headers: headers,
        body: detail.toJson(),
      );
      if (response.statusCode == 200) {
        penjualanDetails.add(PenjualanDetail.fromJson(json.decode(response.body)));
      } else {
        errorMessage.value = 'Failed to add penjualan detail';
      }
    } catch (e) {
      errorMessage.value = e.toString();
    }
  }

  Future<void> updatePenjualanDetail(int id, PenjualanDetail detail) async {
    try {
      final token = _authController.token;
      final headers = {
        'Accept': 'application/json',
        'Authorization': 'Bearer $token',
      };
      final response = await http.put(
        Uri.parse('${ApiEndpoints.PENJUALAN_DETAIL}/$id'),
        headers: headers,
        body: detail.toJson(),
      );
      if (response.statusCode == 200) {
        final index = penjualanDetails.indexWhere((d) => d.id == id);
        if (index != -1) {
          penjualanDetails[index] = PenjualanDetail.fromJson(json.decode(response.body));
        }
      } else {
        errorMessage.value = 'Failed to update penjualan detail';
      }
    } catch (e) {
      errorMessage.value = e.toString();
    }
  }

  Future<void> deletePenjualanDetail(int id) async {
    try {
      final token = _authController.token;
      final headers = {
        'Accept': 'application/json',
        'Authorization': 'Bearer $token',
      };
      final response = await http.delete(
        Uri.parse('${ApiEndpoints.PENJUALAN_DETAIL}/$id'),
        headers: headers,
      );
      if (response.statusCode == 200) {
        penjualanDetails.removeWhere((d) => d.id == id);
      } else {
        errorMessage.value = 'Failed to delete penjualan detail';
      }
    } catch (e) {
      errorMessage.value = e.toString();
    }
  }
}
